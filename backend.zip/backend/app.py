from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import zipfile
import random
import shutil

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "http://localhost:5173"}})

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ✅ Fix YOLO folder structure if using train2017/val2017
def fix_dataset_structure(base_path):
    images_path = os.path.join(base_path, 'images')
    labels_path = os.path.join(base_path, 'labels')

    # Rename train2017 → train if present
    train_img_2017 = os.path.join(images_path, 'train2017')
    train_lbl_2017 = os.path.join(labels_path, 'train2017')

    if os.path.exists(train_img_2017):
        os.rename(train_img_2017, os.path.join(images_path, 'train'))
    if os.path.exists(train_lbl_2017):
        os.rename(train_lbl_2017, os.path.join(labels_path, 'train'))

    # Verify required folders exist
    if not os.path.exists(os.path.join(images_path, 'train')):
        raise FileNotFoundError("❌ 'images/train/' not found after extraction.")
    if not os.path.exists(os.path.join(labels_path, 'train')):
        raise FileNotFoundError("❌ 'labels/train/' not found after extraction.")

# ✅ Split train into train/val/test (80/15/5)
def split_dataset(base_path, train_ratio=0.8, val_ratio=0.15, test_ratio=0.05):
    image_dir = os.path.join(base_path, 'images', 'train')
    label_dir = os.path.join(base_path, 'labels', 'train')

    all_images = [f for f in os.listdir(image_dir) if f.lower().endswith(('.jpg', '.png'))]
    total = len(all_images)

    if total == 0:
        raise FileNotFoundError("❌ No images found in 'images/train/'.")

    random.shuffle(all_images)
    train_end = int(total * train_ratio)
    val_end = train_end + int(total * val_ratio)

    splits = {
        'train': all_images[:train_end],
        'val': all_images[train_end:val_end],
        'test': all_images[val_end:]
    }

    for split, files in splits.items():
        img_out = os.path.join(base_path, 'images', split)
        lbl_out = os.path.join(base_path, 'labels', split)
        os.makedirs(img_out, exist_ok=True)
        os.makedirs(lbl_out, exist_ok=True)

        for img_file in files:
            label_file = img_file.replace('.jpg', '.txt').replace('.png', '.txt')

            src_img = os.path.join(image_dir, img_file)
            src_lbl = os.path.join(label_dir, label_file)

            if os.path.exists(src_img):
                shutil.move(src_img, os.path.join(img_out, img_file))
            if os.path.exists(src_lbl):
                shutil.move(src_lbl, os.path.join(lbl_out, label_file))

    # Remove empty 'train' folders
    if os.path.isdir(image_dir) and not os.listdir(image_dir):
        os.rmdir(image_dir)
    if os.path.isdir(label_dir) and not os.listdir(label_dir):
        os.rmdir(label_dir)

    print("✅ Dataset split completed (80% train, 15% val, 5% test)")

# ✅ Main upload route
@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    save_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(save_path)

    if file.filename.endswith('.zip'):
        extract_path = os.path.join(UPLOAD_FOLDER, file.filename.rsplit('.', 1)[0])
        with zipfile.ZipFile(save_path, 'r') as zip_ref:
            zip_ref.extractall(extract_path)

        try:
            print("✅ Fixing dataset structure...")
            fix_dataset_structure(extract_path)
            print("✅ Splitting dataset...")
            split_dataset(extract_path)

            return jsonify({
                'message': 'ZIP uploaded, extracted, structure fixed, and dataset split',
                'filename': file.filename,
                'path': extract_path
            })

        except Exception as e:
            print("❌ Exception during upload:", str(e))  # 👈 ADD THIS LINE
            return jsonify({'error': str(e)}), 500

    return jsonify({'message': 'Non-ZIP file uploaded (no split attempted)', 'filename': file.filename})


# ✅ Import your YOLO route blueprints (unchanged)
from routes.train import train_bp
from routes.val import val_bp
from routes.test import test_bp
from routes.export import export_bp
from routes.yaml_gen import yaml_bp

app.register_blueprint(train_bp, url_prefix='/train')
app.register_blueprint(val_bp, url_prefix='/val')
app.register_blueprint(test_bp, url_prefix='/test')
app.register_blueprint(export_bp, url_prefix='/export')
app.register_blueprint(yaml_bp, url_prefix='/generate_yaml')

if __name__ == '__main__':
    app.run(debug=True)
