# routes/test.py
from flask import Blueprint, request, jsonify
import os
from ultralytics import YOLO

test_bp = Blueprint('test_bp', __name__)

@test_bp.route('/', methods=['POST'])
def test_model():
    data = request.get_json()
    dataset_path = data.get('dataset_path')

    test_images_path = os.path.join(dataset_path, 'images', 'test')
    weights_path = os.path.join('results/train/run/weights', 'best.pt')

    if not os.path.exists(test_images_path):
        return jsonify({'error': f'Test images not found at: {test_images_path}'}), 404
    if not os.path.exists(weights_path):
        return jsonify({'error': f'Trained weights not found at: {weights_path}'}), 404

    try:
        model = YOLO(weights_path)
        model.predict(
            source=test_images_path,
            project='results/test',
            name='run',
            save=True,         # Save predicted images
            exist_ok=True
        )
        return jsonify({'message': 'Testing completed'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
