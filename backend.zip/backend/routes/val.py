# routes/val.py
from flask import Blueprint, request, jsonify
import os
from ultralytics import YOLO

val_bp = Blueprint('val_bp', __name__)

@val_bp.route('/', methods=['POST'])
def validate_model():
    data = request.get_json()
    dataset_path = data.get('dataset_path')  # still used for UI purposes

    # YAML and model path
    yaml_path = os.path.join('results/yaml', 'data.yaml')
    weights_path = os.path.join('results/train/run/weights', 'best.pt')

    # Check existence
    if not os.path.exists(yaml_path):
        return jsonify({'error': 'YAML not found at results/yaml/data.yaml'}), 404
    if not os.path.exists(weights_path):
        return jsonify({'error': 'Trained weights not found at results/train/run/weights/best.pt'}), 404

    try:
        model = YOLO(weights_path)
        model.val(
            data=yaml_path,
            project='results/val',
            name='run',
            exist_ok=True
        )
        return jsonify({'message': 'Validation completed'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
