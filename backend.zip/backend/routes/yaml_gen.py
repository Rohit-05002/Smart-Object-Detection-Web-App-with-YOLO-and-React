from flask import Blueprint, request, jsonify
import os
import yaml
import requests

yaml_bp = Blueprint('yaml_bp', __name__)

MODEL_URLS = {
    'YOLOv8n': 'https://github.com/ultralytics/assets/releases/download/v8.1.0/yolov8n.pt',
    'YOLOv8s': 'https://github.com/ultralytics/assets/releases/download/v8.1.0/yolov8s.pt',
    'YOLOv8m': 'https://github.com/ultralytics/assets/releases/download/v8.1.0/yolov8m.pt',
    'YOLOv8l': 'https://github.com/ultralytics/assets/releases/download/v8.1.0/yolov8l.pt',
    'YOLOv8x': 'https://github.com/ultralytics/assets/releases/download/v8.1.0/yolov8x.pt',
    'YOLOv9': 'https://github.com/ultralytics/assets/releases/download/v8.1.0/yolov9.pt',
    'YOLOv10': 'https://github.com/ultralytics/assets/releases/download/v8.1.0/yolov10.pt'
}

@yaml_bp.route('/', methods=['POST'])
def generate_yaml():
    data = request.get_json()
    dataset_path = data.get('dataset_path')
    num_classes = data.get('num_classes')
    model_name = data.get('model')

    if not dataset_path or num_classes is None or not model_name:
        return jsonify({'error': 'Missing dataset_path, num_classes or model'}), 400

    # ✅ Generate YAML with absolute paths
    yaml_data = {
        'train': os.path.abspath(os.path.join(dataset_path, 'images', 'train')),
        'val': os.path.abspath(os.path.join(dataset_path, 'images', 'val')),
        'test': os.path.abspath(os.path.join(dataset_path, 'images', 'test')),
        'nc': num_classes,
        'names': [f'class_{i}' for i in range(num_classes)]
    }

    os.makedirs('results/yaml', exist_ok=True)
    yaml_path = os.path.join('results/yaml', 'data.yaml')
    with open(yaml_path, 'w') as f:
        yaml.dump(yaml_data, f)

    # ✅ Download model weights if needed
    if model_name != "Custom Model":
        pt_url = MODEL_URLS.get(model_name)
        pt_file = f"{model_name}.pt"
        if pt_url and not os.path.exists(pt_file):
            try:
                print(f"⬇️ Downloading {pt_file} from {pt_url}")
                r = requests.get(pt_url)
                with open(pt_file, 'wb') as f:
                    f.write(r.content)
                print(f"✅ Downloaded {pt_file}")
            except Exception as e:
                print(f"❌ Failed to download {pt_file}: {e}")
                return jsonify({'error': f'Model download failed: {e}'}), 500

    return jsonify({'message': 'YAML generated and model checked', 'yaml_path': yaml_path})
