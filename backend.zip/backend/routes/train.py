from flask import Blueprint, request, jsonify
import os
from ultralytics import YOLO

train_bp = Blueprint('train_bp', __name__)

@train_bp.route('/', methods=['POST'])
def train_model():
    data = request.get_json()
    dataset_path = data.get('dataset_path')
    model_name = data.get('model')

    yaml_path = os.path.join('results/yaml', 'data.yaml')
    if not os.path.exists(yaml_path):
        print("❌ YAML file not found at:", yaml_path)
        return jsonify({'error': 'data.yaml not found'}), 404

    # ✅ Model name mapping
    model_map = {
        'YOLOv8n': 'yolov8n.pt',
        'YOLOv8s': 'yolov8s.pt',
        'YOLOv8m': 'yolov8m.pt',
        'YOLOv8l': 'yolov8l.pt',
        'YOLOv8x': 'yolov8x.pt',
        'YOLOv9': 'yolov9.pt',
        'YOLOv10': 'yolov10.pt',
        'Custom Model': 'custom_model.yaml'
    }

    model_path = model_map.get(model_name)
    if model_path is None:
        return jsonify({'error': f'Unsupported model: {model_name}'}), 400

    if not os.path.exists(model_path):
        print("❌ Model file not found at:", model_path)
        return jsonify({'error': f'Model weights not found: {model_path}'}), 404

    try:
        print("✅ Starting training...")
        print("YAML path:", yaml_path)
        print("Model path:", model_path)

        model = YOLO(model_path)
        model.train(
            data=yaml_path,
            epochs=3,
            imgsz=640,
            project='results/train',
            name='run',
            exist_ok=True
        )

        print("✅ Training completed successfully.")
        return jsonify({'message': 'Training completed'})

    except Exception as e:
        print("❌ Exception during training:", str(e))
        return jsonify({'error': str(e)}), 500
