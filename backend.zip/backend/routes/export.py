from flask import Blueprint, request, jsonify
import os
import shutil
from ultralytics import YOLO

export_bp = Blueprint('export_bp', __name__)

@export_bp.route('/', methods=['POST'])
def export_model():
    weights_path = os.path.join('results/train/run/weights', 'best.pt')
    export_output_dir = 'results/export'
    os.makedirs(export_output_dir, exist_ok=True)
    output_onnx_path = os.path.join(export_output_dir, 'exported_model.onnx')

    if not os.path.exists(weights_path):
        return jsonify({'error': f'Trained weights not found at {weights_path}'}), 404

    try:
        model = YOLO(weights_path)
        result = model.export(
            format='onnx',
            imgsz=640,
            dynamic=True,
            simplify=False
        )

        # result is a dict with paths like:
        # {'format': 'onnx', 'path': 'results/train/run/weights/best.onnx'}
        exported_path = result.get('path')
        if exported_path and os.path.exists(exported_path):
            shutil.copy(exported_path, output_onnx_path)
            return jsonify({
                'message': 'Exported model successfully',
                'export_path': output_onnx_path
            })
        else:
            return jsonify({'error': 'ONNX file not found after export'}), 500

    except Exception as e:
        print("❌ Export exception:", str(e))
        return jsonify({'error': str(e)}), 500
