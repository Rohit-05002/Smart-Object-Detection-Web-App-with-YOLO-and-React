import subprocess

def validate_model(data):
    model = data.get("model")
    path = data.get("dataset_path")
    try:
        result = subprocess.run(
            ["yolo", "task=detect", "mode=val", f"model={model}", f"data={path}/data.yaml"],
            capture_output=True, text=True
        )
        return result.stdout
    except Exception as e:
        return str(e)
