import subprocess

def train_model(data):
    path = data.get("dataset_path")
    model = data.get("model")
    num_classes = str(data.get("num_classes"))
    try:
        result = subprocess.run(
            ["yolo", "task=detect", "mode=train", f"model={model}", f"data={path}/data.yaml", "epochs=20"],
            capture_output=True, text=True
        )
        return result.stdout
    except Exception as e:
        return str(e)
