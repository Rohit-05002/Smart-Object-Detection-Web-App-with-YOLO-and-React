import os
import yaml

def generate_yaml(data):
    path = data.get("dataset_path")
    num_classes = data.get("num_classes")
    class_names = data.get("class_names")  # List of class names

    yaml_content = {
        'train': os.path.join(path, 'images/train'),
        'val': os.path.join(path, 'images/val'),
        'nc': num_classes,
        'names': class_names
    }

    try:
        with open(os.path.join(path, 'data.yaml'), 'w') as f:
            yaml.dump(yaml_content, f)
        return "YAML file created."
    except Exception as e:
        return str(e)
