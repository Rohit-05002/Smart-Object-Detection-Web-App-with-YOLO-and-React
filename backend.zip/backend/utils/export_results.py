import subprocess

def export_model(data):
    model = data.get("model")
    try:
        result = subprocess.run(
            ["yolo", "mode=export", f"model={model}", "format=onnx"],
            capture_output=True, text=True
        )
        return result.stdout
    except Exception as e:
        return str(e)
