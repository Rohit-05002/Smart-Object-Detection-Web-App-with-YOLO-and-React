import subprocess

def test_model(data):
    model = data.get("model")
    path = data.get("dataset_path")
    try:
        result = subprocess.run(
            ["yolo", "task=detect", "mode=predict", f"model={model}", f"source={path}/images/test"],
            capture_output=True, text=True
        )
        return result.stdout
    except Exception as e:
        return str(e)
